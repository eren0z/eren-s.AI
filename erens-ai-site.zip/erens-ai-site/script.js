
const menuBtn = document.querySelector('.menu-btn');
const menu = document.querySelector('.menu');
if(menuBtn){
  menuBtn.addEventListener('click', ()=> menu.classList.toggle('open'));
}
document.getElementById('yil').textContent = new Date().getFullYear();

// simple toaster
function notify(msg){
  const t = document.createElement('div');
  t.textContent = msg;
  t.style.position='fixed'; t.style.bottom='20px'; t.style.left='50%';
  t.style.transform='translateX(-50%)'; t.style.background='rgba(0,0,0,.8)';
  t.style.color='#fff'; t.style.padding='10px 14px'; t.style.borderRadius='10px';
  t.style.zIndex='9999'; t.style.boxShadow='0 10px 30px rgba(0,0,0,.4)';
  document.body.appendChild(t);
  setTimeout(()=>{ t.remove(); }, 2400);
}
